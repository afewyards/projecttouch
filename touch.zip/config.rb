require 'compass-colors'

project_type = "stand_alone"
http_path = "../"
css_dir = "styles"
sass_dir = "styles"
images_path = "images"
javascripts_dir = "app"
output_style = "compact"