({
    baseUrl: ".",
    name: "application",
    out: "application.min.js",
    useStrict: true,
    waitSeconds: 3,
    paths: {
        backbone: "empty:",
        underscore: "empty:",
        jquery: "empty:",
        hammer: "empty:"
    }    
})